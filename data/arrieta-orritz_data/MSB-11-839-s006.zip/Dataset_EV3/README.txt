Dataset EV3. TFA estimation for TFs with more than 10 experimentally validated targets.
Each point corresponds to the results of one microarray experiment and TFAs are estimated for each experimental condition. Blue is activation, red is repression.

